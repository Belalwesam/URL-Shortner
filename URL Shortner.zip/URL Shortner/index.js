document.querySelector(".nav-btn").addEventListener('click' , ()=> {
    document.querySelector(".nav-btn").classList.toggle("active")
   document.querySelector(".nav-links").classList.toggle("active");
})
const shortBtn=document.getElementById("short-btn");
const btns = document.querySelectorAll(".copy-btn");
const links = document.querySelectorAll(".gen-link");
const input = document.getElementById("input");
const father = document.getElementById("father");
shortBtn.addEventListener("click" , (e)=> {
    e.preventDefault();
  /*links.forEach(link => {
   link.classList.add("display");
  })*/
  if (input.value == '') {
      input.classList.add("error")
  } else {
   input.classList.remove("error")
   let El = document.createElement("div");
   El.className ="gen-link d-flex justify-content-between px-4 py-3 align-items-md-center my-4 my-md-2"
   El.innerHTML =`<div class="target-link">
   <p class="m-0">${input.value}</p>
 </div>
 <div class="done-link mt-3 mt-md-0">
   <a href="https://${input.value}/">https://rel.ink/k4lKyk</a>
   <button class="copy-btn ml-0 ml-md-3 mt-3 mt-md-0" id="btn">Copy</button>
 </div>`;
  /*
   let node = `<div class="gen-link d-none justify-content-between px-4 py-3 align-items-md-center my-4 my-md-2" >
   <div class="target-link">
     <p class="m-0">${input.value}</p>
   </div>
   <div class="done-link mt-3 mt-md-0">
     <a href="#">https://rel.ink/k4lKyk</a>
     <button class="copy-btn ml-0 ml-md-3 mt-3 mt-md-0" id="btn">Copy</button>
   </div>
 </div>`;*/
 father.appendChild(El)
 const btns = document.querySelectorAll(".copy-btn");
 btns.forEach(btn => {
    btn.addEventListener("click" ,()=> {
     btn.innerHTML ="Copied!"
     btn.classList.add('copied');
    })
  })
}
})
